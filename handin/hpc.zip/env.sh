#!/bin/bash
module load languages/intel/2018-u3
